from setuptools import setup

setup(name='funniestjoke',
      version='0.1',
      description='The funniest joke in the world',
      url='http://github.com/jeremyzhang2008/funniest',
      author='Jeremy Zhang',
      author_email='jeremy.zhangzq@gmail.com',
      license='MIT',
      packages=['funniestjoke'],
      zip_safe=False)